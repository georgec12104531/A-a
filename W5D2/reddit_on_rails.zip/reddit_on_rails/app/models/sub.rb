class Sub < ApplicationRecord
  validates :description, :name, presence: true
  validates :name, uniqueness: true

  has_many :post_subs
  has_many :posts

  belongs_to :moderator,
    class_name: :User,
    foreign_key: :moderator_id,
    primary_key: :id,

end
