import { createStore } from 'redux';
import rootReducer from '../reducers/root_reducer';
import { applyMiddleware } from 'redux';
import logger from 'redux-logger';

const configureStore = () => {
  const store = createStore(rootReducer, applyMiddleware(logger));
  return store;
}

export default configureStore;
