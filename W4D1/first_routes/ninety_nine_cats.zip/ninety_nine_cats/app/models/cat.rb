class Cat < ApplicationRecord 
  
  validates :birth_date, :color, :name, :sex, :description, presence: true
  COLORS = ['green', 'blue', 'red', 'yellow', 'orange', 'purple']
  
  validates :color, :inclusion => { :in => COLORS }
  validates :sex, :inclusion => { :in => ["F", "M"] }
end