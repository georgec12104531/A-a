class ApplicationController < ActionController::Base
  
  
  def hello 
    redirect_to '/cats/new'
  end
end
