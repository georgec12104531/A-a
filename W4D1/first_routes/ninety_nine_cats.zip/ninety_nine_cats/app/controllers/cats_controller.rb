class CatsController < ApplicationController
  def index
    @cats = Cat.all
    render 'index'
  end
  
  def show
    @cat = Cat.find_by(id: params[:id])
    render 'show'
  end
  
  def new
    @cat = Cat.new
    render 'new'
  end
  
  def create 
    cat1 = Cat.new(cat_params)
    if cat1.save 
      redirect_to cat_url(cat1.id)
    else 
      render json: cat1.errors.full_messages
    end
  end
  
  def edit 
    @cat = Cat.find_by(id: params[:id])
    render 'edit'
  end
  
  def update
    cat1 = Cat.find_by(id: params[:id])
    if cat1.update_attributes(cat_params)
      redirect_to cat_url(cat1)
    else
      render json: cat1.errors.full_messages
    end
  end
  
  private 

  def cat_params
    params.require(:cat).permit(:color, :name, :description, :birth_date, :sex)
  end
end