# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


# create_table "cats", force: :cascade do |t|
#   t.date "birth_date", null: false
#   t.string "color", null: false
#   t.string "name", null: false
#   t.string "sex", null: false
#   t.text "description", null: false
#   t.datetime "created_at", null: false
#   t.datetime "updated_at", null: false

cat1 = Cat.create(birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'F', description: 'Fluffy' )
cat2 = Cat.create(birth_date: '2015/01/20', color: 'green', name: 'Sam', sex: 'F', description: 'Fluffy' )
cat3 = Cat.create(birth_date: '2015/01/20', color: 'purple', name: 'Will', sex: 'M', description: 'Fluffy' )
# cat = Cat.create(birth_date: '2015/01/20', color: 'blue', name: 'Sam', sex: 'F', description: 'Fluffy' )
# cat = Cat.create(birth_date: '2015/01/20', color: 'blue', name: 'Will', sex: 'M', description: 'Fluffy' )

# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )
# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )
# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )
# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )
# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )
# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )
# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )
# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )
# Cat.create (birth_date: '2015/01/20', color: 'blue', name: 'Joey', sex: 'female', description: 'Fluffy' )