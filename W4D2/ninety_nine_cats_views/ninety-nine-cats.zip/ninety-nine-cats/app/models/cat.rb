class Cat < ActiveRecord::Base 

  # //associations go here

  def age 
    self.birth_date 
  end

end