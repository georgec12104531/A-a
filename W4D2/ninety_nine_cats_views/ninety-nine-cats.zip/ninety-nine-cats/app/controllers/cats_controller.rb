CatsController < ApplicationController

  def index
  end

  def show
  end

end