class ModifyComments < ActiveRecord::Migration[5.1]
  def change
    add_column :comments, :body, :string, null:false
    add_column :comments, :user_id, :integer, null:false
    add_column :comments, :link_id, :integer, null:false

    add_index :comments, :user_id, unique: true
    add_index :comments, :link_id, unique: true
  end
end
