class ModifyLinks < ActiveRecord::Migration[5.1]
  def change
    add_column :links, :url, :string, null:false
    add_column :links, :title, :string, null:false
    add_column :links, :user_id, :integer, null:false

    add_index :links, :user_id, unique: true
  end
end
