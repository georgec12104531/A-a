# == Schema Information
#
# Table name: links
#
#  id      :bigint(8)        not null, primary key
#  url     :string           not null
#  title   :string           not null
#  user_id :integer          not null
#

class Link < ApplicationRecord

  validates :title, :url, presence: true

  # belongs_to :user
  # has_many :comments

  belongs_to :user,
   class_name: 'User',
   foreign_key: :user_id,
   primary_key: :id

 has_many :comments,
   class_name: 'Comment',
   foreign_key: :link_id,
   primary_key: :id


end
